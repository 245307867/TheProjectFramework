//
//  HomeTableViewCell.h
//  TheProjectFrameWork
//
//  Created by maple on 16/6/4.
//  Copyright © 2016年 MapleDongSen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeTableViewCell : UITableViewCell
/**  首页ImageView */
@property (weak, nonatomic) IBOutlet UIImageView *homeCellImageView;

@end
