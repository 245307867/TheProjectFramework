//
//  PersonalCollectionViewCell.m
//  TheProjectFrameWork
//
//  Created by maple on 16/6/3.
//  Copyright © 2016年 MapleDongSen. All rights reserved.
//

#import "PersonalCollectionViewCell.h"

@implementation PersonalCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end
