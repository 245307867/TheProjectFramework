//
//  GoodsDetialViewController.h
//  TheProjectFrameWork
//
//  Created by maple on 16/6/8.
//  Copyright © 2016年 MapleDongSen. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ShoppingModel;
@interface GoodsDetialViewController : UIViewController
@property(strong,nonatomic) ShoppingModel * goodsmodel;
@end
