//
//  SearchViewController.h
//  TheProjectFrameWork
//
//  Created by maple on 16/6/7.
//  Copyright © 2016年 MapleDongSen. All rights reserved.
//

#import "BaseViewController.h"
#import <UIKit/UIKit.h>
@interface SearchViewController : BaseViewController
/** 弹出视图VC */
@property(strong,nonatomic) UIViewController *presentViewController;
@end
