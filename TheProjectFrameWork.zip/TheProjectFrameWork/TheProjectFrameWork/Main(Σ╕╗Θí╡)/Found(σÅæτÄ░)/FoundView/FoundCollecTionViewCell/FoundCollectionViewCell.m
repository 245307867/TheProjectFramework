//
//  FoundCollectionViewCell.m
//  TheProjectFrameWork
//
//  Created by maple on 16/6/5.
//  Copyright © 2016年 MapleDongSen. All rights reserved.
//

#import "FoundCollectionViewCell.h"

@implementation FoundCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end
