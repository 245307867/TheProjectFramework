//
//  UrlMacros.h
//  TheProjectFrameWork
//
//  Created by maple on 16/6/3.
//  Copyright © 2016年 MapleDongSen. All rights reserved.
//

#ifndef UrlMacros_h
#define UrlMacros_h

//服务器根路径
#define KAppRootUrl  @"192.168.1.1"


#define KApploginUrl  @"192.168.1.1"




#endif /* UrlMacros_h */
